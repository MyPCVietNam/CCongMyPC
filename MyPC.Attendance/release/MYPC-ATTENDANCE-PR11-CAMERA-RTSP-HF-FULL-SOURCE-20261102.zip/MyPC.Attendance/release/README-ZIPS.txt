See CI/artifacts or branch release/ after unpacking CHANGELOG; ZIPs published separately to avoid nesting.
