﻿# Read-only GitHub ZIP verifier for MyPC Attendance PR #12
# PowerShell 5.1 compatible; downloads archives only; never runs extracted code.
param(
    [string]$OutputDir = "$env:USERPROFILE\Downloads\MyPC-PR12-P0TX-Verify"
)
$ErrorActionPreference = 'Stop'
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
$commit = 'FEATURE_PLACEHOLDER'
$github = 'https://raw.githubusercontent.com/MyPCVietNam/CCongMyPC/' + $commit + '/MyPC.Attendance/audit/handoffs/PR12-P0-TX-INTEGRITY-20261103'
$files = @(
    @{ Name='MyPC.Attendance-CHANGED-PR12-P0TX-52b2683caaf0.zip'; Bytes=1513921 },
    @{ Name='MyPC.Attendance-FULL-PR12-P0TX-52b2683caaf0.zip'; Bytes=3348847 }
)
New-Item -ItemType Directory -Path $OutputDir -Force | Out-Null
$manifestPath = Join-Path $OutputDir 'SHA256SUMS.txt'
Invoke-WebRequest -Uri ($github + '/SHA256SUMS.txt') -UseBasicParsing -OutFile $manifestPath
$manifest = Get-Content -LiteralPath $manifestPath -Raw -Encoding UTF8
Add-Type -AssemblyName System.IO.Compression.FileSystem
foreach ($spec in $files) {
    $name = [string]$spec.Name
    $destination = Join-Path $OutputDir $name
    Invoke-WebRequest -Uri ($github + '/' + $name) -UseBasicParsing -OutFile $destination
    $actualSize = (Get-Item -LiteralPath $destination).Length
    if ($actualSize -ne [long]$spec.Bytes) {
        throw "SIZE MISMATCH: $name expected=$($spec.Bytes), actual=$actualSize"
    }
    $hashLine = @($manifest -split '\r?\n' | Where-Object { $_ -match ('\s+' + [regex]::Escape($name) + '$') })
    if ($hashLine.Count -ne 1) { throw "Missing/ambiguous SHA256 manifest entry: $name" }
    $matchSha = [regex]::Match($hashLine[0], '^([0-9a-fA-F]{64})\s+')
    if (-not $matchSha.Success) { throw "Malformed SHA256 manifest entry: $name" }
    $expectedSha = $matchSha.Groups[1].Value.ToLowerInvariant()
    $actualSha = (Get-FileHash -Algorithm SHA256 -LiteralPath $destination).Hash.ToLowerInvariant()
    if ($actualSha -ne $expectedSha) { throw "SHA256 FAIL: $name expected=$expectedSha actual=$actualSha" }
    $archive = [System.IO.Compression.ZipFile]::OpenRead($destination)
    try {
        $entries = @($archive.Entries)
        $totalBytes = [long]0
        $names = @{}
        foreach ($entry in $entries) {
            $entryName = [string]$entry.FullName
            if ($entryName.StartsWith('/') -or $entryName.Contains('..\') -or $entryName -match '(^|/)\.\.(/|$)' -or $entryName.StartsWith('\\')) {
                throw "UNSAFE ZIP ENTRY PATH: $entryName"
            }
            if ($names.ContainsKey($entryName)) { throw "DUPLICATE ZIP ENTRY: $entryName" }
            $names[$entryName] = $true
            $totalBytes += [long]$entry.Length
            if ($totalBytes -gt 500MB) { throw "Uncompressed size exceeded limit" }
        }
        Write-Host "PASS: $name SHA256=$actualSha ZIP_ENTRIES=$($entries.Count)" -ForegroundColor Green
    }
    finally { $archive.Dispose() }
}
$headPath = Join-Path $OutputDir 'FINAL_HEAD.txt'
Invoke-WebRequest -Uri ($github + '/FINAL_HEAD.txt') -UseBasicParsing -OutFile $headPath
$headText = Get-Content -LiteralPath $headPath -Raw -Encoding UTF8
if ($headText -notmatch [regex]::Escape($commit)) {
    Write-Warning "FINAL_HEAD.txt does NOT match actual GitHub commit: $commit"
} else {
    Write-Host 'FINAL_HEAD: PASS' -ForegroundColor Green
}
Write-Host "Downloaded and verified archives at: $OutputDir"
Write-Host 'NOTE: This verifies ZIP bytes/hash and central directory only; it does not run application tests.'
